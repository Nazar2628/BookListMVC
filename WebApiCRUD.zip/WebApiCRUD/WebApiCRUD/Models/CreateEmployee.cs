﻿namespace WebApiCRUD.Models
{
    public class CreateEmployee
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public string Position { get; set; }
    }
}
